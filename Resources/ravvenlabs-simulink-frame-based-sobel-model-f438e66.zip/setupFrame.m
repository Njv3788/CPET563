% Dr. Kaputa
% Frame Based Sobel Demo Setup File
c = 752; 
r = 480;
