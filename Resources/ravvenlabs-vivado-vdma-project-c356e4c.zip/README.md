This repository contains a Xilinx Vivado 2019.1 project that enables the Mathworks Virtual Camera capability in a Zynq SoC FPGA.  
